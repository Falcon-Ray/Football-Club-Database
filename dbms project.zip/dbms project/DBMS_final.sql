-- MySQL dump 10.13  Distrib 5.7.18, for Linux (x86_64)
--
-- Host: localhost    Database: FCB
-- ------------------------------------------------------
-- Server version	5.7.18-0ubuntu0.16.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Apparels`
--

DROP TABLE IF EXISTS `Apparels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Apparels` (
  `Player_ID` int(11) NOT NULL,
  `Product` varchar(20) NOT NULL,
  `Entry_date` date NOT NULL,
  `Price` int(11) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`Player_ID`,`Product`,`Entry_date`),
  CONSTRAINT `Apparels_ibfk_1` FOREIGN KEY (`Player_ID`) REFERENCES `Player` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Apparels`
--

LOCK TABLES `Apparels` WRITE;
/*!40000 ALTER TABLE `Apparels` DISABLE KEYS */;
INSERT INTO `Apparels` VALUES (1,'shoes','2016-06-24',1200,35),(2,'pads','2016-11-13',300,100),(2,'shin guard','2016-08-24',2000,50),(3,'band','2016-08-24',2500,40),(4,'football','2016-08-11',3000,70),(6,'jersey','2016-09-17',1200,60),(7,'shoes','2016-10-22',2300,10),(8,'shoes','2016-10-15',2400,40),(9,'band','2016-12-25',1200,45),(10,'shin pads','2016-06-28',1000,40);
/*!40000 ALTER TABLE `Apparels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Employee`
--

DROP TABLE IF EXISTS `Employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Employee` (
  `ID` int(11) NOT NULL,
  `Username` varchar(20) DEFAULT NULL,
  `E_Name` varchar(20) DEFAULT NULL,
  `Designation` varchar(20) DEFAULT NULL,
  `Manager_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `Username` (`Username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Employee`
--

LOCK TABLES `Employee` WRITE;
/*!40000 ALTER TABLE `Employee` DISABLE KEYS */;
INSERT INTO `Employee` VALUES (1,'Leo','Lionel Messi','Player',1),(2,'Finisher','Luiz','Player',1),(3,'style','Neymar','Player',1),(4,'Class','Andres Iniesta','Player',1),(5,'Portugese','Andre Gomes','Player',1),(6,'Beast','Samuel Umtiti','Player',1),(7,'Biter','Luiz','Player',1),(8,'Height','Gerrard Pique','Player',1),(9,'Wall','Marc Ter Stegen','Player',1),(10,'Legend','Javier Mascherano','Player',1),(11,'Vision','Ivan Rakitic','Shooting Coach',1),(12,'Dribbler','Ronaldo','Passing Coach',1),(13,'Loser','Benzema','injury staff',1),(14,'Head','Ramos','Header Coach',1),(15,'Controller','Marcelo','Cross Coach',1),(16,'Saver','Manuel Neur','Saves Coach',1),(17,'Mr perfect','Toni Kroos','Passing coach',1),(18,'Defender','Lucas Digne','Defending Caoch',1),(19,'Run','Arjen Robben','Running Coach',1),(20,'Stay','Boateng','Defending Coach',1),(21,'Park','Jose Mourinho','Manager',1),(22,'Klopp','Jurgen Klopp','Manager',2),(23,'Angry','Zinedine Zidane','Manager',3),(24,'Leader','Antonio Conte','Manager',4),(25,'Aged','Arsene Wenger','Manager',5),(26,'Mid field','Pep Guardiola','Manager',6),(27,'Legnd','Alex Ferguson','Manager',7),(28,'Passing master','Luis Enrique','Manager',8),(29,'Athlete','Unai Emery','Manager',9),(30,'Excited','Diego Simeone','Manager',10);
/*!40000 ALTER TABLE `Employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Income`
--

DROP TABLE IF EXISTS `Income`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Income` (
  `I_Source` varchar(20) NOT NULL,
  `I_Year` date NOT NULL,
  `Revenue` varchar(20) DEFAULT NULL,
  `I_Type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`I_Source`,`I_Year`),
  UNIQUE KEY `I_Source` (`I_Source`),
  UNIQUE KEY `I_Year` (`I_Year`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Income`
--

LOCK TABLES `Income` WRITE;
/*!40000 ALTER TABLE `Income` DISABLE KEYS */;
INSERT INTO `Income` VALUES ('ADs','2015-12-12','96857','cheque'),('Merchandise','2015-08-17','8576547','cash'),('Museums','2015-09-09','34563','cash'),('Ownership','2016-07-01','243645','cheque'),('Prize money','2016-12-12','435785','cash'),('Sponsors','2016-01-07','07968876','cash'),('Tickets','2015-07-09','087968','cheque'),('Transfers','2016-05-20','776857','cheque'),('Tv deals','2016-06-21','6875855','cash'),('websites','2016-04-04','57645','cash');
/*!40000 ALTER TABLE `Income` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Login_Credentials`
--

DROP TABLE IF EXISTS `Login_Credentials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Login_Credentials` (
  `Username` varchar(20) NOT NULL,
  `LC_Password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Username`),
  CONSTRAINT `Login_Credentials_ibfk_1` FOREIGN KEY (`Username`) REFERENCES `Employee` (`Username`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Login_Credentials`
--

LOCK TABLES `Login_Credentials` WRITE;
/*!40000 ALTER TABLE `Login_Credentials` DISABLE KEYS */;
INSERT INTO `Login_Credentials` VALUES ('Aged','&gdnUGB t5r6gg545'),('Angry','&UGB gdt5r6gg545'),('Athlete','&UGdB t5r6gg545'),('Beast','&UGB t5r6gfngg545'),('Biter','&UGB t5gxr6gg545'),('Class','&UGB t5r6gg545'),('Controller','&UGB ft5gnr6gg545'),('Defender','&UGB t5rgn6gg545'),('Dribbler','&UGB t5r6gg545'),('Excited','&UGB tdb5r6gg545'),('Finisher','&UGB t5rgd6gg545'),('Head','&UGB t5r6ggndg545'),('Height','&UgxGB t5r6gg545'),('Klopp','&UGgndB t5r6gg545'),('Leader','&UGB t5dgr6gg545'),('Legend','&UGB t5r6gg545'),('Legnd','&UGB t5rgd6gg545'),('Leo','&*%gvjvgg545'),('Loser','&UGB t5r6gg545'),('Mid field','&UGB t5dgnr6gg545'),('Mr perfect','&UGBgnd t5r6gg545'),('Park','&UGB gnt5r6gg545'),('Passing master','&UGB t5dgr6gg545'),('Portugese','&HfngBG^*%&755'),('Run','&UGB t5r6gngg545'),('Saver','&UGB t5gnr6gg545'),('Stay','&UGB t5r6gnfxgg545'),('style','&UGilbvfngd76rhjg 45'),('Vision','&UGB t5r6gg545'),('Wall','&UGB t5r6mfygg545');
/*!40000 ALTER TABLE `Login_Credentials` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Maintenance_Expenses`
--

DROP TABLE IF EXISTS `Maintenance_Expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Maintenance_Expenses` (
  `Cause` varchar(50) NOT NULL,
  `ME_Year` date NOT NULL,
  `Cost` int(11) DEFAULT NULL,
  `Paid` int(11) DEFAULT NULL,
  PRIMARY KEY (`Cause`,`ME_Year`),
  UNIQUE KEY `Cause` (`Cause`),
  UNIQUE KEY `ME_Year` (`ME_Year`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Maintenance_Expenses`
--

LOCK TABLES `Maintenance_Expenses` WRITE;
/*!40000 ALTER TABLE `Maintenance_Expenses` DISABLE KEYS */;
INSERT INTO `Maintenance_Expenses` VALUES ('ads','2016-02-16',32678,25000),('awards','2016-05-02',7687000,26700),('Clothing','2016-01-27',324000,3000),('family','2016-05-01',242230,22300),('food','2016-06-21',434000,21000),('incentives','2016-08-21',24500,2000),('laundry','2016-07-13',454000,34000),('personal','2016-05-29',356000,27800),('Sponsors','2016-05-03',7865000,45600),('travel','2016-05-21',234000,21000);
/*!40000 ALTER TABLE `Maintenance_Expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Manager`
--

DROP TABLE IF EXISTS `Manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Manager` (
  `ID` int(11) NOT NULL,
  `DOB` date DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `M_Status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `Manager_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `Employee` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Manager`
--

LOCK TABLES `Manager` WRITE;
/*!40000 ALTER TABLE `Manager` DISABLE KEYS */;
INSERT INTO `Manager` VALUES (21,'1985-02-19',500000,32,0),(22,'1972-02-19',786500,45,0),(23,'1969-02-19',450000,48,0),(24,'1973-02-19',760000,44,0),(25,'1982-02-19',6700000,36,0),(26,'1981-02-19',1230000,37,0),(27,'1984-02-19',4320000,33,0),(28,'1970-02-19',800000,37,0),(29,'1978-02-19',820000,38,0),(30,'1965-02-19',768000,52,1);
/*!40000 ALTER TABLE `Manager` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Manager_join`
--

DROP TABLE IF EXISTS `Manager_join`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Manager_join` (
  `Join_Date` date NOT NULL,
  `ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`Join_Date`),
  KEY `ID` (`ID`),
  CONSTRAINT `Manager_join_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `Manager` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Manager_join`
--

LOCK TABLES `Manager_join` WRITE;
/*!40000 ALTER TABLE `Manager_join` DISABLE KEYS */;
INSERT INTO `Manager_join` VALUES ('2000-01-01',21),('2001-01-01',22),('2002-01-01',23),('2003-01-01',24),('2004-01-01',25),('2005-01-01',26),('2006-01-01',27),('2007-01-01',28),('2008-01-01',29),('2009-01-01',30);
/*!40000 ALTER TABLE `Manager_join` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Matches`
--

DROP TABLE IF EXISTS `Matches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Matches` (
  `M_Date` date NOT NULL,
  `Stadium_Name` varchar(20) DEFAULT NULL,
  `Manager_ID` int(11) DEFAULT NULL,
  `Team` varchar(20) DEFAULT NULL,
  `League` varchar(20) DEFAULT NULL,
  `League_Standings` int(11) DEFAULT NULL,
  `Result` varchar(20) DEFAULT NULL,
  `Referee` varchar(20) DEFAULT NULL,
  `Possession` int(11) DEFAULT NULL,
  PRIMARY KEY (`M_Date`),
  KEY `Stadium_Name` (`Stadium_Name`),
  KEY `Manager_ID` (`Manager_ID`),
  CONSTRAINT `Matches_ibfk_1` FOREIGN KEY (`Stadium_Name`) REFERENCES `Stadium` (`St_name`) ON DELETE CASCADE,
  CONSTRAINT `Matches_ibfk_2` FOREIGN KEY (`Manager_ID`) REFERENCES `Manager` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Matches`
--

LOCK TABLES `Matches` WRITE;
/*!40000 ALTER TABLE `Matches` DISABLE KEYS */;
INSERT INTO `Matches` VALUES ('2000-04-23','Anoeta',21,'Sevilla','La liga',4,'won','Lewandowski',76),('2001-06-01','Riazor',22,'Las Palmas','La liga',3,'won','Ibrahamovic',58),('2002-08-25','Camp Nou',23,'Real Madrid','La liga',2,'won','Bale',53),('2003-12-13','El Minon',24,'Osasuna','La liga',4,'won','Anthonio',76),('2004-11-09','San Mames',25,'Espanyol','La liga',2,'won','Mike Dean',67),('2005-03-09','Mestalla',26,'Manchester city','Champions League',1,'won','Andre Marinner',63),('2006-02-02','Santiago Bernabeu',27,'Monaco','Champions League',5,'lost','Carl Chefferes',57),('2007-10-15','Balaidos',28,'Bayern Munich','Champions League',4,'won','Jerome Boger',59),('2008-02-28','El Minon',29,'Swansea','Champions League',1,'lost','Terry Mcaulay',50),('2009-04-16','Olimpio de sevilla',30,'Athletico Madrid','Copa Del Rey',2,'won','Micheal Oliver',68);
/*!40000 ALTER TABLE `Matches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Matches_Result`
--

DROP TABLE IF EXISTS `Matches_Result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Matches_Result` (
  `Result` varchar(20) DEFAULT NULL,
  `Goals_Scored` int(11) NOT NULL,
  `Goals_Conceded` int(11) NOT NULL,
  PRIMARY KEY (`Goals_Scored`,`Goals_Conceded`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Matches_Result`
--

LOCK TABLES `Matches_Result` WRITE;
/*!40000 ALTER TABLE `Matches_Result` DISABLE KEYS */;
INSERT INTO `Matches_Result` VALUES ('lost',0,2),('lost',0,3),('lost',0,4),('lost',0,5),('won',2,0),('won',2,1),('won',3,2),('lost',3,4),('won',4,0),('won',5,0);
/*!40000 ALTER TABLE `Matches_Result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Met_By`
--

DROP TABLE IF EXISTS `Met_By`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Met_By` (
  `Exp_Cause` varchar(20) NOT NULL,
  `Exp_Year` date NOT NULL,
  `Income_Source` varchar(20) DEFAULT NULL,
  `Income_Year` date DEFAULT NULL,
  PRIMARY KEY (`Exp_Cause`,`Exp_Year`),
  KEY `Exp_Year` (`Exp_Year`),
  KEY `Income_Source` (`Income_Source`),
  KEY `Income_Year` (`Income_Year`),
  CONSTRAINT `Met_By_ibfk_1` FOREIGN KEY (`Exp_Cause`) REFERENCES `Maintenance_Expenses` (`Cause`) ON DELETE CASCADE,
  CONSTRAINT `Met_By_ibfk_2` FOREIGN KEY (`Exp_Year`) REFERENCES `Maintenance_Expenses` (`ME_Year`) ON DELETE CASCADE,
  CONSTRAINT `Met_By_ibfk_3` FOREIGN KEY (`Income_Source`) REFERENCES `Income` (`I_Source`) ON DELETE CASCADE,
  CONSTRAINT `Met_By_ibfk_4` FOREIGN KEY (`Income_Year`) REFERENCES `Income` (`I_Year`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Met_By`
--

LOCK TABLES `Met_By` WRITE;
/*!40000 ALTER TABLE `Met_By` DISABLE KEYS */;
INSERT INTO `Met_By` VALUES ('ads','2016-02-16','Merchandise','2015-08-17'),('awards','2016-05-02','websites','2016-04-04'),('Clothing','2016-01-27','Tickets','2015-07-09'),('family','2016-05-01','Prize money','2016-12-12'),('food','2016-06-21','Transfers','2016-05-20'),('personal','2016-05-29','ADs','2015-12-12'),('Sponsors','2016-05-03','Museums','2015-09-09'),('travel','2016-05-21','Tv deals','2016-06-21');
/*!40000 ALTER TABLE `Met_By` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Player`
--

DROP TABLE IF EXISTS `Player`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Player` (
  `ID` int(11) NOT NULL,
  `DOB` date DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `Position` varchar(20) DEFAULT NULL,
  `Foot` varchar(20) DEFAULT NULL,
  `Height` int(11) DEFAULT NULL,
  `Weight` int(11) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Previous_club` varchar(20) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL,
  `Selling_cost` int(11) DEFAULT NULL,
  `Contract_date` date DEFAULT NULL,
  `p_status` tinyint(1) DEFAULT NULL,
  `Join_date` date DEFAULT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `Player_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `Employee` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Player`
--

LOCK TABLES `Player` WRITE;
/*!40000 ALTER TABLE `Player` DISABLE KEYS */;
INSERT INTO `Player` VALUES (1,'1991-02-19','france','offensive midfielder','right',183,80,25,'athletico madrid',600000,1000000,'2022-12-20',1,'2014-05-14'),(2,'1990-08-13','Germany','defensive midfielder','left',180,70,26,'espanyol',700000,2000000,'2023-12-20',1,'2015-05-14'),(3,'1986-10-30','Italy','offensive defender','right',170,78,30,'Liverpool',800000,3000000,'2018-12-20',1,'2016-05-14'),(4,'1985-03-17','Spain','defensive midfielder','right',181,79,31,'Real madrid',900000,1000000,'2024-12-20',1,'2004-05-14'),(5,'1989-09-30','Spain','right back','right',177,69,27,'Las palmas',1000000,4000000,'2017-12-20',1,'2009-05-14'),(6,'1980-11-22','Hungary','left back','left',179,75,36,'Chelsea',500000,6000000,'2026-12-20',1,'2010-05-14'),(7,'1990-07-07','Columbia','center back','right',190,90,26,'Bayern Munich',550000,1000000,'2020-12-20',1,'2011-05-14'),(8,'1988-01-18','India','goal keeper','right',192,88,24,'Osasuna',670000,8000000,'2025-12-20',1,'2013-05-14'),(9,'1979-02-08','Turkey','Center forward','left',184,81,35,'Sevilla',820000,9000000,'2027-12-20',1,'2014-05-14'),(10,'1992-11-01','Romania','winger','right',187,78,23,'Arsenal',900000,1000000,'2030-12-20',1,'2015-05-14');
/*!40000 ALTER TABLE `Player` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Player_Jersey`
--

DROP TABLE IF EXISTS `Player_Jersey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Player_Jersey` (
  `jersey_number` int(11) NOT NULL,
  `ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`jersey_number`),
  KEY `ID` (`ID`),
  CONSTRAINT `Player_Jersey_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `Player` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Player_Jersey`
--

LOCK TABLES `Player_Jersey` WRITE;
/*!40000 ALTER TABLE `Player_Jersey` DISABLE KEYS */;
INSERT INTO `Player_Jersey` VALUES (10,1),(13,2),(69,3),(67,4),(5,5),(54,6),(32,7),(11,8),(100,9),(7,10);
/*!40000 ALTER TABLE `Player_Jersey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Plays`
--

DROP TABLE IF EXISTS `Plays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Plays` (
  `Player_ID` int(11) NOT NULL,
  `Match_Date` date NOT NULL,
  PRIMARY KEY (`Player_ID`,`Match_Date`),
  KEY `Match_Date` (`Match_Date`),
  CONSTRAINT `Plays_ibfk_1` FOREIGN KEY (`Player_ID`) REFERENCES `Player` (`ID`) ON DELETE CASCADE,
  CONSTRAINT `Plays_ibfk_2` FOREIGN KEY (`Match_Date`) REFERENCES `Matches` (`M_Date`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Plays`
--

LOCK TABLES `Plays` WRITE;
/*!40000 ALTER TABLE `Plays` DISABLE KEYS */;
INSERT INTO `Plays` VALUES (1,'2000-04-23'),(2,'2001-06-01'),(3,'2002-08-25'),(4,'2003-12-13'),(5,'2004-11-09'),(6,'2005-03-09'),(7,'2006-02-02'),(8,'2007-10-15'),(9,'2008-02-28'),(10,'2009-04-16');
/*!40000 ALTER TABLE `Plays` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Stadium`
--

DROP TABLE IF EXISTS `Stadium`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Stadium` (
  `St_name` varchar(20) NOT NULL,
  `Place` varchar(20) DEFAULT NULL,
  `Matches` int(11) DEFAULT NULL,
  `Capacity` int(11) DEFAULT NULL,
  `Won` int(11) DEFAULT NULL,
  `Lost` int(11) DEFAULT NULL,
  `Ticket_cost` int(11) DEFAULT NULL,
  PRIMARY KEY (`St_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Stadium`
--

LOCK TABLES `Stadium` WRITE;
/*!40000 ALTER TABLE `Stadium` DISABLE KEYS */;
INSERT INTO `Stadium` VALUES ('Anoeta','San Sebastian',124,32076,123,0,6500),('Balaidos','Vigo',68,29000,57,11,1200),('Camp Nou','Barcelona',104,99354,89,18,10000),('El Minon','Gijon',59,30000,30,10,10000),('Mestalla','Valencia',76,55000,56,4,1000),('Olimpio de sevilla','Seville',134,60000,65,23,13456),('Riazor','A coruna',98,34600,57,13,12000),('San Mames','Bilbao',70,53289,50,110,8796),('Santiago Bernabeu','Madrid',165,81044,100,32,12000),('Vicente carlon','Madrid',123,54678,89,12,11897);
/*!40000 ALTER TABLE `Stadium` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Staff`
--

DROP TABLE IF EXISTS `Staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Staff` (
  `ID` int(11) NOT NULL,
  `Designation` varchar(20) DEFAULT NULL,
  `Start_Date` date DEFAULT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `Age` int(11) DEFAULT NULL,
  `Salary` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  CONSTRAINT `Staff_ibfk_1` FOREIGN KEY (`ID`) REFERENCES `Employee` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Staff`
--

LOCK TABLES `Staff` WRITE;
/*!40000 ALTER TABLE `Staff` DISABLE KEYS */;
INSERT INTO `Staff` VALUES (11,'Shooting Coach','2014-01-01','Argentina',32,400000),(12,'Passing Coach','2010-01-01','Cameroon',32,320000),(13,'Injury Staff','2013-01-01','Spain',23,560000),(14,'Header Coach','2012-01-01','USA',31,7465000),(15,'Controller','2015-01-01','Turkey',21,876200),(16,'Saves Coach','2010-01-01','Brazil',39,475000),(17,'Passing Coach','2016-01-01','France',27,4987000),(18,'Defender','2013-01-01','Portugal',28,897000),(19,'Running Coach','2008-01-01','Greece',33,354600),(20,'Defending Coach','2012-01-01','Albania',34,4756000);
/*!40000 ALTER TABLE `Staff` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Statistics`
--

DROP TABLE IF EXISTS `Statistics`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Statistics` (
  `Player_ID` int(11) NOT NULL,
  `Match_Date` date NOT NULL,
  `Goals` int(11) DEFAULT NULL,
  `Passes` int(11) DEFAULT NULL,
  `Duels_Won` int(11) DEFAULT NULL,
  `Tackles` int(11) DEFAULT NULL,
  `Clearances` int(11) DEFAULT NULL,
  `Blocks` int(11) DEFAULT NULL,
  `Interceptions` int(11) DEFAULT NULL,
  `Fouls` int(11) DEFAULT NULL,
  `Yellow_Cards` int(11) DEFAULT NULL,
  `Red_Cards` int(11) DEFAULT NULL,
  `Penalties` int(11) DEFAULT NULL,
  `Crosses` int(11) DEFAULT NULL,
  PRIMARY KEY (`Player_ID`,`Match_Date`),
  CONSTRAINT `Statistics_ibfk_1` FOREIGN KEY (`Player_ID`) REFERENCES `Player` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Statistics`
--

LOCK TABLES `Statistics` WRITE;
/*!40000 ALTER TABLE `Statistics` DISABLE KEYS */;
INSERT INTO `Statistics` VALUES (1,'2009-02-16',3,456,34,45,32,34,67,7,2,0,1,10),(2,'2004-11-09',4,345,30,23,32,34,67,7,2,1,0,15),(3,'2006-02-02',3,500,20,42,32,34,67,7,2,0,1,21),(4,'2003-12-13',2,445,34,76,32,34,67,7,2,1,0,13),(5,'2001-06-01',0,345,23,12,32,34,67,7,2,0,1,13),(6,'2001-01-23',0,654,58,32,32,34,67,7,2,1,0,10),(7,'2008-02-21',1,100,32,76,32,34,67,7,2,0,1,17),(8,'2012-04-10',7,324,86,34,32,34,67,7,2,1,0,22),(9,'2013-07-01',2,387,65,24,32,34,67,7,2,0,1,17),(10,'2005-12-27',6,490,76,65,32,34,67,7,2,1,0,18);
/*!40000 ALTER TABLE `Statistics` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Transfers`
--

DROP TABLE IF EXISTS `Transfers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Transfers` (
  `Contract_Date` date NOT NULL,
  `Player_ID` int(11) NOT NULL,
  `Country` varchar(20) DEFAULT NULL,
  `Last_Club` varchar(20) DEFAULT NULL,
  `Current_Club` varchar(20) DEFAULT NULL,
  `Deal_Price` int(11) DEFAULT NULL,
  `Deal` varchar(20) DEFAULT NULL,
  `Player_Name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Contract_Date`,`Player_ID`),
  KEY `Player_ID` (`Player_ID`),
  CONSTRAINT `Transfers_ibfk_1` FOREIGN KEY (`Player_ID`) REFERENCES `Player` (`ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Transfers`
--

LOCK TABLES `Transfers` WRITE;
/*!40000 ALTER TABLE `Transfers` DISABLE KEYS */;
INSERT INTO `Transfers` VALUES ('2019-05-01',4,'Spain','Swansea','Barcelona',8079865,'Bought','Andres Iniesta'),('2020-05-01',5,'Spain','Self Managed','Barcelona',9879687,'Bought','Andre Gomes'),('2020-05-01',6,'Hungary','Osasuna','Barcelona',8079685,'Bought','Samuel Umtiti'),('2021-05-01',8,'India','Real Madrid','Espanyol',87957677,'sold','Gerrard Pique'),('2022-05-01',1,'France','Sevilla','Barcelona',8796853,'Bought','Lionel Messi'),('2022-05-01',2,'Italy','Bayern Munich','Athletico Madrid',80796888,'sold','Luiz'),('2022-05-01',3,'Geramny','Arsenal','Barcelona',8079689,'Bought','Neymar'),('2022-05-01',9,'Turkey','Espanyol','Barcelona',32446780,'Bought','Marc Ter Stegen'),('2022-05-01',10,'Romania','Monaco','Barcelona',9807965,'Bought','Javier Mascherano'),('2023-05-01',7,'Columbia','Las Palmas','Villareal',79069857,'sold','Luiz');
/*!40000 ALTER TABLE `Transfers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-04-30 13:06:57
